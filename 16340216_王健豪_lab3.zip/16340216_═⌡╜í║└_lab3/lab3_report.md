# 现代操作系统应用开发实验报告



### 姓名：**王健豪**

### 学号：**16340216**

### 实验名称：**week7-网络访问/week8-音乐播放器**





[TOC]


### 一、 参考

**week7：**

1. [Reference-Thanks very much](https://blog.csdn.net/yaoxh6/article/details/80056321)
2. week7 PPT
3. UWP 官方文档类的介绍
4. Bibli

**week8：**

1. UWP 官方文档
2. week8 PPT
3. github

### 二、 实验步骤

**week7：**

1. 找到合适的 API，并申请 key
2. 用 [website_json](http://json2csharp.com/#) [website_xml](http://xmltocsharp.azurewebsites.net/)将示例的 json or xml 格式，转换成类
3. 在项目中添加相应类，注意 json 类 需要添加 [Datamember] 等修饰
4. 设计 UI
5. 写网络访问处理函数
   1. 首先 解决如何向网站发送带有信息的请求
   2. 如何接收反馈
   3. 如何处理 json or xml 格式 string
   4. 进行 UI 输出

**week8：**

1. 其实没什么步骤，照搬PPT，基本功能都解决了
2. 设置访问选择文件
3. 写全屏函数

### 三、 关键步骤截图

**week7：**

*Code*

```C#
xml
private async void SearchAddressButton_ClickAsync(object sender, RoutedEventArgs e)
{
	string input = SearchInputAddress.Text;
	string input2 = SearchInputAddress2.Text;
	CoordAddressResult data = await xmlway.GetWeather(input, input2);
	string result = "| : Cityname: " + input + "\n| : "
			+ "Country: " + data.Result.Country + "\n| : "
			+ "Country_code: " + data.Result.Country_code + "\n| : "
			+ "Province: " + data.Result.Province + "\n| : "
			+ "City: " + data.Result.City + "\n| : "
			+ "District: " + data.Result.District + "\n| : "
			+ "Street: " + data.Result.Street + "\n| : "
			+ "Street_number: " + data.Result.Street_number;
	Address.Text = result;
}
```

​	

```C#
json
private async void SearchWeatherButton_ClickAsync(object sender, RoutedEventArgs e)
{
	string input = SearchInputWeather.Text;
    // 注意这个 特殊的 RootObject 类，是整个文件的类包含的起始
	RootObject data = await OpenGeoProxy.GetGeoInformation(input);
	string result = "| : Cityname: " + input + "\n| : "
			+ "Humidity: " + data.result.realtime.weather.humidity + "\n| : "
			+ "Img: " + data.result.realtime.weather.img + "\n| : "
			+ "Info: " + data.result.realtime.weather.info + "\n| : "
			+ "Temperature: " + data.result.realtime.weather.temperature;
    // 注意学习上面的访问方式 data.result.realtime.weather.temperature
	Weather.Text = result;
}
```

*Image*

![](.\image\weather.PNG)

![](.\image\loc.PNG)



**week8:**

*Code*

![](.\image\appBarButton.PNG)

*全屏*

![](.\image\fullscreen.PNG)

*选择图片*

![](.\image\select.PNG)

*Result Show*

![](.\image\video.PNG)

*进度条展示*

![](.\image\video2.PNG)



### 四、 亮点与改进（可选）

**week7: **

1. 同时实现了 `xml` 和 `json` 格式文件转换

**week8:**

1. 可以拖动进度条

### 五、 遇到的问题

**week7：**

1. `json` 格式文件获取数据，网上大部分方法是写一个对应的类，但是自己写内容很多，我也只需要一小部分，后来得知有一个 `json to class` 的网站，才能让我不卡在这一步

**week8:**

1. 不知道为什么按照课件里面的 `MediaElement.SpeedRatio` 属性值无法识别，所以放弃了播放速度这一功能

### 六、 思考与总结

​        最近的项目渐渐脱离原本的框架结构，好像自从数据库之后就不再使用了，同步因为作业的追求某一单一的功能，没有变化，所以网上很好找到教程，相对好做一些。

​        希望之后的下半学期的课程相对轻松一些，不然我的其他课有些岌岌可危



*注：此为报告内容的参考结构，可以用自己喜欢的排版*

